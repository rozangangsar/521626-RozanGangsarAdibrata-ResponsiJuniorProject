using System.Drawing.Text;
using System.Linq.Expressions;
using System.Security.Cryptography.X509Certificates;
using Npgsql;
using System.Data;
using System.Runtime.CompilerServices;

namespace ResponsiJunproRozan
{
    public partial class Form1 : Form //inheritance
    {
        private readonly string _cs = "Host=localhost;Port=5432;Username=postgres;Password=aspire4730z;Database=ResponsiJunproRozan"; //enkapsulasi

        public Form1()
        {
            InitializeComponent();
            LoadGrid();
            LoadComboProyek();
            LoadComboKontrak();
        }

        private void LoadGrid()
        {
            try
            {
                using var conn = new NpgsqlConnection(_cs);
                conn.Open();

                const string sql = "SELECT nama_developer, status_kontrak, jumlah_fitur, jumlah_bug, nama_proyek FROM data_dev";

                using var cmd = new NpgsqlCommand(sql, conn);
                using var reader = cmd.ExecuteReader();

                var dt = new DataTable();
                dt.Load(reader);

                dataGridView1.DataSource = dt;
                dataGridView1.ReadOnly = true;
                dataGridView1.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Gagal load data developer: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void LoadComboProyek()
        {
            try
            {
                using var conn = new NpgsqlConnection(_cs);
                conn.Open();

                const string sql = "SELECT DISTINCT nama_proyek FROM data_dev";
                using var cmd = new NpgsqlCommand(sql, conn);
                using var reader = cmd.ExecuteReader();

                var proyekList = new List<string>();
                while (reader.Read())
                {
                    if (!reader.IsDBNull(0))
                        proyekList.Add(reader.GetString(0));
                }

                comboBox1.DataSource = proyekList;
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Gagal load data proyek: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
        private void LoadComboKontrak()
        {
            try
            {
                using var conn = new NpgsqlConnection(_cs);
                conn.Open();
                const string sql = "SELECT DISTINCT status_kontrak FROM data_dev";
                using var cmd = new NpgsqlCommand(sql, conn);
                using var reader = cmd.ExecuteReader();
                var kontrakList = new List<string>();
                while (reader.Read())
                {
                    if (!reader.IsDBNull(0))
                        kontrakList.Add(reader.GetString(0));
                }
                comboBox2.DataSource = kontrakList;
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Gagal load data kontrak: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        public void button1_Click(object sender, EventArgs e)
        {
            var nama = textBox1.Text;
            var (kontrakList, proyekList) = (comboBox2.SelectedItem.ToString(), comboBox1.SelectedItem.ToString());

        }
    }
}

